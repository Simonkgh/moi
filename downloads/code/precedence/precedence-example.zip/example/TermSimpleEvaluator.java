package example;

// Provides a method to convert a TermSimple into some value that the "precedence evaluator" cares about.
//
// In this example, we convert a TermSimple to a boolean by simply "unwrapping" it. For a use-case like
// evaluating an SQL-style expression, this would evaluate a condition like "a=1" or "name like 'm%' and
// return a boolean value.
public class TermSimpleEvaluator {
    public static boolean evaluate(TermSimple term) {
        return term.getValue();
    }
}
