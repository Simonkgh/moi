package example;

import java.util.ArrayList;
import java.util.List;

/** Represents a sequence like "term OP term OP term". */
public class TermCompound implements Term {
    private Term initial;
    private List<Junction> junctions = new ArrayList<>();

    public TermCompound(Term initial) {
        this.initial = initial;
    }

    public void add(Operator op, Term term) {
        this.junctions.add(new Junction(op, term));
    }

    public Term getInitial() {
        return initial;
    }

    public List<Junction> getJunctions() {
        return junctions;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("(");
        sb.append(initial);
        for(Junction j : junctions) {
            sb.append(" ");
            sb.append(j.toString());
        }
        sb.append(")");
        return sb.toString();
    }
}
