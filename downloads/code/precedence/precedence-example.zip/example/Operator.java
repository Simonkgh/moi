package example;

public enum Operator {

    AND(1),
    OR(0);

    private final int precedence;

    private Operator(int precedence) {
        this.precedence = precedence;
    }

    public int getPrecedence() {
        return precedence;
    }
}
