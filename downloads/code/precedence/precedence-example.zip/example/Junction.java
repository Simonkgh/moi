package example;

/**
 * Represents "tail" elements of a list of TERM OP TERM OP TERM ...
 */
public class Junction {
    private final Operator op;
    private final Term term;

    public Junction(Operator op, Term term) {
        this.op = op;
        this.term = term;
    }

    public Operator getOperator() {
        return op;
    }

    public Term getTerm() {
        return term;
    }

    public String toString() {
        return op.toString() + " " + term.toString();
    }
}
