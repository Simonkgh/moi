package example;

/**
 * Do some simple demonstrations of precedence-aware evaluation.
 * <p>
 * Ideally, this would also prove that the boolean evaluator completely skips evaluation of some nodes, eg
 * the RHS of "false and X".
 * </p>
 */
public class Main {
    public static void main(String[] args) {
        test1();
        test2();
    }

    /**
     * Evaluate "true or true and false" which produces "true" with proper precedence-handling, but "false" if
     * simply evaluated left-to-right.
     */
    public static void test1() {
        TermCompound ct = new TermCompound(new TermSimple(true));
        ct.add(Operator.OR, new TermSimple(true));
        ct.add(Operator.AND, new TermSimple(false));

        boolean result = new PrecedenceAwareEvaluator().evaluate(ct);
        System.out.println(String.format("Expr %s -> %s [expect true]", ct, result));
    }

    /**
     * Evaluate an expression with nested subclause.
     */
    public static void test2() {
        TermCompound nested = new TermCompound(new TermSimple(true));
        nested.add(Operator.AND, new TermSimple(true));
        nested.add(Operator.OR, new TermSimple(false));

        TermCompound ct = new TermCompound(new TermSimple(false));
        ct.add(Operator.OR, new TermSimple(false));
        ct.add(Operator.OR, nested);
        ct.add(Operator.AND, new TermSimple(true));

        boolean result = new PrecedenceAwareEvaluator().evaluate(ct);
        System.out.println(String.format("Expr %s -> %s [expect true]", ct, result));
    }
}
