package example;

/**
 * Represents some operation "below the level" that the precedence-evaluator needs to care about.
 * <p>
 * For the use-case of processing SQL expressions, this class would represent an SQL operation like
 * like "count > 0" or "id not like 'foo'".
 * </p>
 * <p>
 * For the purposes of this example, we just wrap a boolean..
 * </p>
 */
public class TermSimple implements Term {
    boolean value;

    public TermSimple(boolean value) {
        this.value = value;
    }

    boolean getValue() {
        return value;
    }

    public String toString() {
        return Boolean.toString(value);
    }
}
