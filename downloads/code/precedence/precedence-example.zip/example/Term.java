package example;

// TermSimple | TermCompound
public interface Term {
}
