# Investigate Efficiency of HBase and Avro Disk Storage

The files in this directory are simple tools that help to answer the following questions:

*  Can data be stored more efficiently in Avro format than in HBase?
*  How do long column-names affect the amount of storage required for records in HBase?
*  Is snappy compression for Avro/HBase worth using?

# Installation

Python3 is required.

All libraries required by these tools can be installed with pip:

If you don't yet have pip:

```
python get-pip.py
```

It is recommended that you ceate a virtual environment:

```
python3 -m venv {name of the env}
source {name of the env}/bin/activate
```

To install packages:

~~~
pip install -r requirements.txt
~~~

It may be necessary to install the `snappy`development libraries on the local machine, in order for `pip install ..` to succeed.
If you do not wish to test Avro output, then the snappy libraries can be commented out in requirements.txt.

~~~
# linux
sudo apt install libsnappy-dev

# mac
brew install snappy
~~~

# HBase Tests

You will of course need a running HBase environment with suitable amounts of HDFS storage to run these tests.

## Setting up target tables

Tables must be created in HBase before loading data into them.

All the following examples assume the standard "`hbase shell`" has been started.

To create standard and snappy-compressed tables:

~~~
create 'tablename', {NAME=>'f1', VERSIONS=>1}
create 'tablename_compressed', {NAME=>'f1', VERSIONS=>1, COMPRESSION=>'SNAPPY'}
~~~

To delete existing tables (for rerunning tests):

~~~
disable 'tablename'
drop 'tablename'
~~~

To verify the number of rows inserted into a table:

~~~
count 'tablename'
~~~

To view some sample data:

~~~
scan 'tablename', {LIMIT=>5}
~~~

## Starting the HBase Thrift Server

If the optional thrift-server interface to HBase has not yet been started, then use one of the following commands:

```
# server will stop when console closes
hbase thrift start -p 9090

# server will continue when console closes
# nohup hbase thrift start -p 9090 &
```

## Loading Data into HBase

The following command will output all supported commandline options:

~~~
python3 hbase_write.py --help
~~~

# Avro Tests

No special environment is required for this test; it just generates files on the local system.

Run the following command to see available commandline options:

~~~
python3 avro_write.py --help
~~~
