"""
A simple program which connects to a remote HBase instance and inserts N rows of randomish data.

This is intended for testing the efficiency of on-disk HBase storage formats.

See readme.md for more details.
"""

import argparse
import happybase as base
import sys
import random

def connect_to_hbase(host, port):
    conn = base.Connection(host=host, port=port, transport='buffered')
    conn.open()
    return conn

def create_randomish_string(rand_src, n):
    """ Return a relatively random string of N characters, and do so quickly """
    bytes = rand_src.getrandbits(n * 4).to_bytes(n // 2, sys.byteorder)
    return bytes.hex()

def choose_columns(family, n_columns, column_name_length, rand_src):
    """ Return a list of N randomish column names """
    columns = []
    for i in range(n_columns):
        column_name = family + ':' + create_randomish_string(rand_src, column_name_length)
        columns.append(column_name)
    return columns

def generate_value(row_num, column_num):
    """
    Return some not-easily-compressible string for use as an HBase cell value.
    Sadly, random number generators are too slow to return a properly random value here.
    """
    return '{}.{}.abc.{}.{}'.format(column_num, row_num, row_num, column_num)

def create_record(row_num, columns):
    record = {}
    for i, colname in zip(range(0, len(columns)), columns):
        record[colname] = generate_value(row_num, i)
    return record

def write_hbase(con, table_name, family, n_rows, n_columns, column_length):
    rand_src = random.Random()
    rand_src.seed(123)
    columns = choose_columns(family, n_columns, column_length, rand_src)

    table = con.table(table_name)
    ba = table.batch(batch_size=1000)
    for row_num in range(n_rows):
        row_key = "row-" + str(row_num)
        row_data = create_record(row_num, columns)
        ba.put(row_key, row_data)  # adding values to batch
        if (row_num % 1000) == 0:
            print("row_num:" + str(row_num))
    ba.send()  # pushing data to the HBase database
    print("Pushed data to the database")

def run():
    parser = argparse.ArgumentParser()

    parser.add_argument('--host', action="store", type=str, dest='host',
                        help='ip address of the database')

    parser.add_argument('--port', action="store", type=int, dest='port',
                        help='port key of the database', default=9090)

    parser.add_argument('--tn', action="store", type=str, dest='table_name',
                        help='table name of the HBase table')

    parser.add_argument('--cf', action="store", type=str, dest='family',
                        help='name of an hbase column_family to define columns in', default='f1')

    parser.add_argument('--nr', action="store", type=int, dest='n_rows',
                        help='defines how many rows will be created', default=10)

    parser.add_argument('--nc', action="store", type=int, dest='n_columns',
                        help='defines how many columns will be created', default=10)

    parser.add_argument('--cl', action="store", type=int, dest='column_length',
                        help='String length of the column', default=10)

    # initialize the variable results with the arguments of the argparser
    args = parser.parse_args()

    # sadly, the happybase connection is not compatible with python "with" syntax
    con = connect_to_hbase(args.host, args.port)
    try:
        write_hbase(con, args.table_name, args.family, args.n_rows, args.n_columns, args.column_length)
    finally:
        con.close()

if __name__ == "__main__":
    run()
