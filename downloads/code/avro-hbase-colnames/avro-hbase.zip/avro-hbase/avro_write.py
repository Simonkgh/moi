"""
An app which creates a local avro datafile with n columns and rows.
For further information see file readme.md
"""

import sys
import avro.schema
from avro.datafile import DataFileWriter
from avro.io import DatumWriter
import json
import argparse
import random

def create_randomish_string(rand_src, n):
    """ Return a relatively random string of N chars, and do so quickly. """
    bytes = rand_src.getrandbits(n * 4).to_bytes(n // 2, sys.byteorder)
    return bytes.hex()

def choose_columns(n_columns, column_name_length):
    """ Return array of N randomish strings, each of the specified length """
    rand_src = random.Random()
    rand_src.seed(123)

    column_list = []
    for i in range(n_columns):
        column_list.append(create_randomish_string(rand_src, column_name_length))
    return column_list

def create_schema_json(columns):
    """ Return an AVRO schema definition in JSON format """
    schema_dict = {"type": "record",
                   "name": "testschema",
                   "namespace": "com.apache.avro",
                   "fields": [
                       {"type": "string",
                        "name": colname
                        } for colname in columns
                   ]}
    json_schema = json.dumps(schema_dict, ensure_ascii=True)
    return json_schema

def create_record(row_num, columns):
    """ Return a dictionary of (colname, value) pairs.  """
    record = {}
    for i, colname in zip(range(0, len(columns)), columns):
        record[colname] = '{}.{}.abc.{}.{}'.format(i, row_num, row_num, i)
    return record

def write_avro(file_name, codec, n_columns, column_length, n_rows):
    columns = choose_columns(n_columns, column_length)
    schema_json = create_schema_json(columns)
    schema = avro.schema.Parse(schema_json)
    with DataFileWriter(open(file_name + ".avro", 'wb'), DatumWriter(), schema, codec=codec) as writer:
        for row_num in range(n_rows):
            record = create_record(row_num, columns)
            writer.append({key: value for key, value in record.items()})
        print("job done")

def run():
    parser = argparse.ArgumentParser()

    parser.add_argument('--outfile', action="store", type=str, dest='outfile',
                        help='name of the file to write to (without suffix)')

    parser.add_argument('--codec', action="store", type=str, dest='codec', default="null",
                        help='codec to use when writing records (eg "snappy")')

    parser.add_argument('--cl', action="store", type=int, dest='column_length',
                        help='string length of the columns')

    parser.add_argument('--nc', action="store", type=int, dest='n_columns',
                        help='how many columns to define per row')

    parser.add_argument('--nr', action="store", type=int, dest='n_rows',
                        help='number of rows of data to write')

    args = parser.parse_args()

    write_avro(args.outfile, args.codec, args.n_columns, args.column_length, args.n_rows)

if __name__ == "__main__":
    run()
