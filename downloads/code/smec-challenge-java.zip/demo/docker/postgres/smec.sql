-- needed by Hibernate/JPA for auto-allocated IDs
CREATE SEQUENCE hibernate_sequence START WITH 1 INCREMENT BY 1;

-- Represents an account.
--
-- Note that (like other tables) postgres column type "text" is currently used for name. I haven't had the time to
-- read the documents on type "text" fully; it is possible that VARCHAR would be more appropriate - but text does
-- have the advantage that it is not necessary to specify a max length at the moment.
create table ACCOUNT(
  id integer primary key,
  name text not null unique
);

-- Represents the "current balance info" for an account.
--
-- Note that this table has a 1:1 relation to account. Such relations are not common; the columns here could
-- just be folded into the account table. However logically the account-balance is *derived* from account-base
-- and the set of events, so it seems more elegant to store it separately.
create table ACCOUNT_BALANCE(
  id integer primary key,
  balance decimal(10, 4) not null
);

-- Represents the "oldest available balance info" for an account.
--
-- Like ACCOUNT_BALANCE, this table has a slightly unusual 1:1 relation to account. However this table is
-- mutable (updated when events are purged) while the data in account is not. It therefore seems appropriate
-- to store it separately.
create table ACCOUNT_BASE(
  id integer primary key,
  balance decimal(10, 4) not null,
  as_at timestamp
);

-- A transaction occurring against an account.
--
-- Note that type is just a plain string at the moment; if the set of available types is limited then it would be
-- more elegant to have a table-of-types and use a foreign-key to it here. However the requirements do not state
-- how many distinct types are available..
--
-- Using (account_id, inserted_at) as a key would be a bad idea if multiple records could be inserted with
-- the same timestamp; that is unlikely but nevertheless using a surrogate key seems better.
create table EVENT(
  id integer primary key,
  account_id integer references ACCOUNT(id),
  inserted_at timestamp not null,
  happened_at timestamp not null,
  type text not null
);

-- Per-day summary of the number of events of each distinct type
--
-- Other records use a surrogate key, but here there is an obvious natural key..
create table STATISTIC(
  account_id integer references ACCOUNT(id),
  day date not null,
  type text not null,
  count integer not null,
  primary key (account_id, day, type)
);