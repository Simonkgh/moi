Implementation of a demo application that provides rest APIs for managing "accounts" and associated events,
persisting these events and providing a few associated features.

Note that the following error presented when the app is run usually means database not running or accessible:
> Access to DialectResolutionInfo cannot be null when 'hibernate.dialect' not set

# Building and launching a database

The following instructions assume you have docker installed locally. They build a container with a postgres
instance initialised with the tables needed by the account-demo java application, and show how to start
and stop that container locally. The container can also be deployed to Kubernetes - though obviously this
approach is only for testing, not production (a DB on a single VM is not very robust).

~~~
docker build -t simon/smecdb docker/postgres

# Start DB as background daemon
# (omit detach option to see output)
docker run --detach -p 5432:5432 --name smecdb simon/smecdb
docker stop smecdb # when not needed
docker start smecdb # to resume database without dataloss

# Interactive shell example
docker exec -it smecdb /bin/sh
su -c psql postgres
\d
\d ACCOUNT
select * from ACCOUNT;
quit
~~~

If a different port-mapping is chosen for the db, update src/main/resources/application.properties
(or override the spring application-properties in the usual spring manner).

# Building and launching the spring app

~~~
mvn install
mvn spring-boot:run
~~~

(Note: DB connection url assumed to be localhost:5432; see above)

App config also assumes local port 8080 is available to listen on.

# Basic Testing Commands

Following commands use the CURL commandline tool to send rest-requests to a running account-demo app.
Obviously there are more sophisticated REST testing tools ;-)

~~~
# Create account MYACCT1
curl -i -X POST http://localhost:8080/account/MYACCT1

# List all accounts
curl -i http://localhost:8080/account

# Insert an event
curl -i -X POST -H "Content-Type: application/json" http://localhost:8080/account/MYACCT1/event \
 --data-raw '{"happenedAt":"2019-01-01T01:02:03Z", "type":"type1"}'

# List all events
curl -i http://localhost:8080/account/MYACCT1/event
~~~
