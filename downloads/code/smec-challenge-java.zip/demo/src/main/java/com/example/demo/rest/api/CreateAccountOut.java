package com.example.demo.rest.api;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Data-structure returned from rest endpoint createAccount.
 */
@JsonInclude(JsonInclude.Include.NON_NULL) // output either error or id, but not both
public class CreateAccountOut {
    // Note: only one of error or id may be non-null
    private final String error; // reason why create-account operation failed
    private final Long id; // id of successfully-created account

    public CreateAccountOut(String error) {
        this.error = error;
        this.id = null;
    }

    public CreateAccountOut(long id) {
        this.error = null;
        this.id = id;
    }

    public String getError() { return error; }
    public Long getId() { return id; }
}
