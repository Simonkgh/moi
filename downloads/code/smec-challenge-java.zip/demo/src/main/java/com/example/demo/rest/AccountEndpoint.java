package com.example.demo.rest;

import com.example.demo.logic.AccountHandler;
import com.example.demo.logic.EventHandler;
import com.example.demo.model.Account;
import com.example.demo.model.BasicPage;
import com.example.demo.model.Event;
import com.example.demo.rest.api.CreateAccountOut;
import com.example.demo.rest.api.PublishEventIn;
import com.example.demo.rest.api.QueryAccountsOut;
import com.example.demo.rest.api.QueryEventsOut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.*;

/**
 * Define REST endpoints associated with accounts.
 */
@RestController
public class AccountEndpoint {
    // Note: constants (static finals) are usually defined in UPPERCASE, but a logger is not really a constant but
    // instead a service..
    private static final Logger logger = LoggerFactory.getLogger(AccountEndpoint.class);

    // For event-filtering, a date "far in the future" is needed for an upper-bound when the caller does not
    // provide one. Weirdly, Instant.MAX is "too large" (causes an exception) deep inside Spring or JPA.
    // There isn't enough time to find a proper solution, but this date should do...
    private static final Instant INSTANT_MAX = LocalDateTime.of(2199, 1, 1, 0, 0).toInstant(ZoneOffset.UTC);

    private final AccountHandler accountHandler;
    private final EventHandler eventHandler;

    // Example of setting http-status of an endpoint method via throwing an annotated exception
    // (rather than returning a ResponseEntity).
    @ResponseStatus(code = HttpStatus.BAD_REQUEST)
    private static class CustomException extends RuntimeException {
    }

    /** Reusable error-result object, created once for efficiency. */
    private final CreateAccountOut CREATE_EXISTS_ERROR;

    /**
     * Constructor.
     */
    @Autowired
    AccountEndpoint(AccountHandler accountHandler, EventHandler eventHandler) {
        this.accountHandler = accountHandler;
        this.eventHandler = eventHandler;

        // Class is immutable, so may as well create it once..
        CREATE_EXISTS_ERROR = new CreateAccountOut("name exists");
    }

    @RequestMapping(path = "/account/{name}", method = RequestMethod.POST, produces = "application/json")
    public ResponseEntity<CreateAccountOut> createAccount(@PathVariable(name = "name") String name) {
        logger.debug("createAccount: name={}", name);
        try {
            long id = accountHandler.createAccount(name);
            logger.debug("createAccount succeeded for {}", name);
            return ResponseEntity.status(HttpStatus.OK).body(new CreateAccountOut(id));
        } catch (AccountHandler.AccountExists e) {
            logger.debug("createAccount invoked with existing name {}", name, e);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(CREATE_EXISTS_ERROR);
        } catch (Exception e) {
            logger.warn("createAccount failed", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @RequestMapping(path = "/account", method = RequestMethod.GET, produces = "application/json")
    public ResponseEntity<QueryAccountsOut> queryAccounts(
            @RequestParam(name = "prefix", required = false) String prefix,
            @RequestParam(name = "from", required = false) Integer from_) {
        logger.debug("queryAccount: prefix={}", prefix);

        prefix = (prefix == null) ? "" : prefix;
        int from = (from_ == null) ? 0 : from_.intValue();
        try {
            BasicPage<Account> page = accountHandler.queryAccounts(prefix, from);
            List<Account> results = page.items();
            QueryAccountsOut result = new QueryAccountsOut(page.pageNum(), page.pageCount(), results);
            return ResponseEntity.status(HttpStatus.OK).body(result);
        } catch (Exception e) {
            logger.warn("queryAccounts failed", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @RequestMapping(path = "/account/{name}/event", method = RequestMethod.POST,
            consumes = "application/json", produces = "application/json")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public ResponseEntity<?> publishEvent(@PathVariable(name = "name") String name, @RequestBody PublishEventIn body) {
        logger.debug("publishEvent: name={}", name);

        try {
            Instant happenedAt = (body.getHappenedAt() == null) ? Instant.now() : body.getHappenedAt();
            String type = (body.getType() == null) ? "" : body.getType();

            long accountId = accountHandler.idForName(name);
            eventHandler.publishEvent(accountId, happenedAt, type);

            // In the current implementation, persistence of the event is immediate, but in more
            // scalable implementations of this API the event might be processed asynchronously.
            // Returning ACCEPTED therefore seems more future-proof than returning OK or NO_CONTENT.
            return ResponseEntity.status(HttpStatus.ACCEPTED).build();
        } catch (AccountHandler.AccountNotFound e) {
            // TODO: is this really the right status code?
            // Nothing else seems more appropriate though (eg NOT_FOUND seems misleading)..
            logger.debug("publishEvent: failed to find account {}", name);
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        } catch (Exception e) {
            logger.warn("publishEvent failed", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @RequestMapping(path = "/account/{name}/event", method = RequestMethod.GET, produces = "application/json")
    public ResponseEntity<?> queryEvents(@PathVariable(name = "name") String name,
                                         @RequestParam(name = "from", required = false) Instant from_,
                                         @RequestParam(name = "to", required = false) Instant to_,
                                         @RequestParam(name = "page", required = false) Integer page_) {
        logger.debug("queryEvents: name={}", name);

        try {
            int page = (page_ == null) ? 0 : page_.intValue();
            Instant from = (from_ == null) ? Instant.EPOCH : from_;
            Instant to = (to_ == null) ? INSTANT_MAX : to_;

            // Note that two separate database round-trips are happening here; first a query to look up account,
            // then another to fetch the events. Possibly a single SQL-query with join could be used to do both
            // in one operation (DB round-trip) - but it doesn't seem worth the effort here.
            Account account = accountHandler.forName(name);
            BasicPage<Event> results = eventHandler.queryEvents(account.getId(), from, to, page);

            QueryEventsOut rsp = new QueryEventsOut(results.pageNum(), results.pageCount(), account, results.items());
            return ResponseEntity.status(HttpStatus.OK).body(rsp);
        } catch (AccountHandler.AccountNotFound e) {
            logger.debug("queryEvents: failed to find account {}", name);
            // This http-status code doesn't seem entirely natural, but no other standard code feels better...
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        } catch (Exception e) {
            logger.warn("queryEvents failed", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
