package com.example.demo.logic;

import com.example.demo.dao.EventDAO;
import com.example.demo.model.BasicPage;
import com.example.demo.model.Event;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import javax.transaction.Transactional;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Implementation of EventHandler reads/writes a database via JPA.
 */
@Component
@Profile("!mem")
public class EventHandlerImpl implements EventHandler {
    private final EventDAO dao;

    @Autowired
    EventHandlerImpl(EventDAO dao) {
        this.dao = dao;
    }

    /**
     * Save event, update AccountBalance, and update Statistics in one atomic transaction.
     * <p>
     * In a more scalable system, this method might instead write the event to a message-broker then return,
     * and allow some message-listener (or listeners) to perform these operations.
     * </p>
     */
    @Transactional(rollbackOn = {Exception.class}) //rollback on checked exceptions as well as unchecked ones..
    public void publishEvent(long accountId, Instant happenedAt, String type) throws PersistenceException {
        try {
            Event e = new Event(accountId, happenedAt, type);
            long id = dao.save(e).getId();
            System.out.println("id:" + id);

            // update the AccountBalance record, eg
            //   "UPDATE ACCOUNT_BALANCE SET BALANCE = BALANCE + ? WHERE ACCOUNT_ID = ?"
            //
            // Update the Statistic record, handling the case where there is no record for that day
            //  nrowsUpdated = "UPDATE STATISTIC SET COUNT = COUNT + 1 where accountId=? and day=? and type=?
            //  if nrows == 0 then INSERT STATISTIC ...
        } catch(Exception e) {
            throw new PersistenceException(e);
        }
    }

    public BasicPage<Event> queryEvents(long accountId, Instant from, Instant to, int page)
            throws PersistenceException {
        try {
            Pageable p = PageRequest.of(page, MAX_RESULTS);
            Page results = dao.findEvents(accountId, from, to, p);
            return new BasicPage(results.getNumber(), results.getTotalPages(), results.getContent());
        } catch(Exception e) {
            throw new PersistenceException(e);
        }
    }
}
