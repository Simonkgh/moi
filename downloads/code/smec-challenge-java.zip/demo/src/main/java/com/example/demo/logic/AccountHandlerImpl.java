package com.example.demo.logic;

import com.example.demo.dao.AccountDAO;
import com.example.demo.model.Account;
import com.example.demo.model.BasicPage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import javax.transaction.Transactional;
import java.util.List;

/**
 * Implementation of AccountHandler which reads/writes a relational database via JPA.
 */
@Component
@Profile("!mem")
public class AccountHandlerImpl implements AccountHandler {
    private final AccountDAO dao;

    /** Constructor. */
    @Autowired
    AccountHandlerImpl(AccountDAO dao) {
        this.dao = dao;
    }

    /**
     * Inserts new account entity into the database and returns its auto-allocated key.
     */
    @Transactional(rollbackOn = {Exception.class}) //rollback on checked exceptions as well as unchecked ones..
    public long createAccount(String name) throws AccountExists, PersistenceException {
        Account a = new Account(name);
        try {
            long id = dao.save(a).getId();

            // TODO: also insert an ACCOUNT_BALANCE record with zero balance.
            // Alternative would be to create the ACCOUNT_BALANCE record on demand, but missing
            // balance records might make reporting and similar tasks more complex, so best to
            // insert it immediately. That implies this method should be @Transactional..

            return id;
        } catch(DataIntegrityViolationException e) {
            throw new AccountExists();
        } catch(Exception e) {
            // Map DB-specific exception to generic exception type that callers can handle without
            // JPA-specific code, or dealing with "Exception" in general.
            throw new PersistenceException(e);
        }
    }

    public BasicPage<Account> queryAccounts(String prefix, int page) throws PersistenceException {
        try {
            Pageable p = PageRequest.of(page, MAX_RESULTS);
            Page<Account> resultPage = dao.findByNamePattern(prefix + "%", p);
            return new BasicPage<>(resultPage.getNumber(), resultPage.getTotalPages(), resultPage.getContent());
        } catch(Exception e) {
            throw new PersistenceException(e);
        }
    }

    public long idForName(String name) throws AccountNotFound, PersistenceException {
        // Possibly could look up id in local cache here before querying DB..
        return forName(name).getId();
    }

    public Account forName(String name) throws AccountNotFound, PersistenceException {
        try {
            // select from Accounts where name = name
            List<Account> accounts = dao.findByName(name);
            if (accounts.isEmpty()) {
                throw new AccountNotFound();
            }
            // there is a unique constraint on account.name, so can never be more than one..
            return accounts.get(0);
        } catch(AccountNotFound e) {
            throw e; // handle case of exception thrown directly in try above
        } catch(Exception e) {
            throw new PersistenceException(e);
        }
    }
}
