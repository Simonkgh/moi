package com.example.demo.rest.api;

import com.example.demo.model.Account;

import java.util.List;

/**
 * Data-structure returned from rest endpoint queryAccounts.
 */
public class QueryAccountsOut {
    private final int pageNum;
    private final int pageMax;
    private final List<Account> accounts;

    public QueryAccountsOut(int pageNum, int pageMax, List<Account> accounts) {
        this.pageNum = pageNum;
        this.pageMax = pageMax;
        this.accounts = accounts; // defensive copy does not seem necessary here
    }

    public int getPageNum() { return pageNum; }
    public int getPageMax() { return pageMax; }
    public List<Account> getAccounts() { return accounts; }
}
