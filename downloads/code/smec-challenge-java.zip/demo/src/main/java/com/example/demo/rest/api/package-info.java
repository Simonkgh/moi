/**
 * DTOs corresponding to the JSON passed into rest endpoints, and JSON returned out of rest endpoints.
 * <p>
 * All classes here must be mappable from or to JSON, using Spring's default JSON mapper (Jackson). In most
 * cases, classes and fields do not need custom annotations but annotations from com.fasterxml.jackson.annotation
 * may be used if needed.
 * </p>
 * <p>
 * Where possible, these classes embed types from package "model", ie the DTOs used for database persistence.
 * However care should be taken - in some cases, a DTO intended for database persistence may contain fields that
 * are not appropriate for exposing to client applications, in which case data must be copied between internal
 * and external representations, or a custom JSON serialized defined for the type. Note in particular that DTO class
 * Account has an "id" field; this is not really relevant for clients as they always refer to accounts by name - but
 * the requirements show account-id being included in JSON output, so it does not need to be suppressed (which makes
 * life easier as the Account DTO can be directly reused for JSON serialization).
 * </p>
 * <p>
 * For input-types, ie where a JSON deserializer instantiates the type, there are two options for a constructor:
 * (a) provide a default constructor, and mutable fields or (b) provide a suitably annotated constructor, in which
 * case the fields can be final. Having final fields is more elegant, but the constructor is often ugly. Currently,
 * option (a) has been taken for simplicity.
 * </p>
 */
package com.example.demo.rest.api;