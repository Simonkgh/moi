package com.example.demo.logic;

/**
 * Represents an inability to read or write persistent data - independent of the actual mechanism.
 * <p>
 * This is possibly overkill, but it is nice not to let exceptions related to a specific persistence
 * library propagate out of this package without being wrapped..
 * </p>
 */
public class PersistenceException extends Exception {
    public PersistenceException(Throwable cause) {
        super(cause);
    }
}
