package com.example.demo.rest.api;

import java.time.Instant;

/**
 * JSON body required on call to rest-endpoint publishEvent.
 */
public class PublishEventIn {
    private Instant happenedAt;
    private String type;

    /** Default constructor for JSON deserialization. */
    PublishEventIn() { }

    /** Constructor. */
    PublishEventIn(Instant happenedAt, String type) {
        this.happenedAt = happenedAt;
        this.type = type;
    }

    public Instant getHappenedAt() { return happenedAt; }
    public String getType() { return type; }
}
