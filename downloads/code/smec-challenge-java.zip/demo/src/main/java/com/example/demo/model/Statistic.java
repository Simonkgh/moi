package com.example.demo.model;

import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * Data model for business domain concept "Statistic".
 */
@Entity
public class Statistic {
    @Embeddable
    public static class StatisticKey implements Serializable {
        private long accountId;
        private LocalDate day;
        private String type;

        StatisticKey() {}

        StatisticKey(long accountId, LocalDate day, String type) {
            this.accountId = accountId;
            this.day = day;
            this.type = type;
        }
    }

    @EmbeddedId
    private StatisticKey id;
    private long count;

    /**
     * Package-scoped constructor for JPA.
     */
    Statistic() {
    }

    public Statistic(long accountId, LocalDate day, String type) {
        this.id = new StatisticKey(accountId, day, type);
    }

    public long getCount() { return count; }
}
