package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * Data model for business domain concept "Account".
 */
@Entity
public class Account {
    /** Database key of this account. */
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    /** Human-readable name for this account. */
    private String name;

    /** Package-scoped constructor for JPA. */
    Account() { }

    /** Constructor. */
    public Account(long id, String name) {
        this.id = id;
        this.name = name;
    }

    /** Constructor. */
    public Account(String name) {
        this.name = name;
    }

    public long getId() {
        return id;
    }
    void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }
    void setName(String name) {
        this.name = name;
    }
}
