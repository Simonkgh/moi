package com.example.demo.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a "page" of values.
 * <p>
 * This class should possibly be moved to a different package, as it isn't directly a domain-model DTO. However
 * it is likely to *contain* such types in its items-list...
 * </p>
 */
public class BasicPage<T> {
    private final int pageNum;
    private final int pageCount;
    private final List<T> items;

    public BasicPage(int pageNum, int pageCount, List<T> items) {
        this.pageNum = pageNum;
        this.pageCount = pageCount;

        // make defensive copy, as caller might be providing a list that is later mutated.
        this.items = new ArrayList<>(items);
    }

    public int pageNum() { return pageNum; }
    public int pageCount() { return pageCount; }
    public List<T> items() { return items; }
}
