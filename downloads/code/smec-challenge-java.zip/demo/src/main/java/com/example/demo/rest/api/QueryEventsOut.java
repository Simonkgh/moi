package com.example.demo.rest.api;

import com.example.demo.model.Account;
import com.example.demo.model.Event;

import java.util.List;

/**
 * Data-structure returned from rest endpoint queryEvents.
 */
public class QueryEventsOut {
    private final int pageNum;
    private final int pageMax;
    private final Account account; // account with which events are associated
    private final List<Event> events; // a page-full of events

    public QueryEventsOut(int pageNum, int pageMax, Account account, List<Event> events) {
        this.pageNum = pageNum;
        this.pageMax = pageMax;
        this.account = account;
        this.events = events; // defensive copy does not seem necessary here
    }

    public int getPageNum() { return pageNum; }
    public int getPageMax() { return pageMax; }
    public Account getAccount() { return account; }
    public List<Event> getEvents() {
        return events;
    }
}
