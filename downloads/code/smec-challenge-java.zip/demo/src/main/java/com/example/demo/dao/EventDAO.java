package com.example.demo.dao;

import com.example.demo.model.Account;
import com.example.demo.model.Event;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.List;

/**
 * Interface defining which event-related database access methods Spring should auto-generate implementations for.
 */
public interface EventDAO extends CrudRepository<Event, Long> {
    /**
     * Return all events for the specified account, between the specified timestamps, and limit result-set size
     * with paging.
     */
    @Query(value = "select e from Event e where accountId = ?1 and happenedAt >= ?2 and happenedAt <= ?3 order by happenedAt")
    Page<Event> findEvents(long accountId, Instant from, Instant to, Pageable page);
}