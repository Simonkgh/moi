package com.example.demo.logic;

import com.example.demo.model.BasicPage;
import com.example.demo.model.Event;

import java.time.Instant;
import java.util.List;

/**
 * Functions related to manipulating instances of type Event..
 */
public interface EventHandler {
    public static final int MAX_RESULTS = 10;

    /**
     * Persist event.
     * <p>
     * The implementation might write directly to a database, or write the event to a queue, or take any other
     * action that somehow ensures the event is not lost. There is no guarantee that on completion of this
     * method the event is visible via a call to queryEvents - ie publish may be asynchronous with respect to
     * queryEvents depending on implementation.
     * </p>
     */
    void publishEvent(long accountId, Instant happenedAt, String type) throws PersistenceException;

    BasicPage<Event> queryEvents(long accountId, Instant from, Instant to, int page) throws PersistenceException;
}
