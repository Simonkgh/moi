package com.example.demo.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.time.Instant;

/**
 * Data model for business domain concept "Event".
 */
@Entity
public class Event {
    @JsonIgnore // database key of this event is not relevant to clients, so hidden in JSON
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id; // record key
    private long accountId; // id of the account associated with this event
    private Instant insertedAt; // time event inserted into DB (seems useful to have)
    private Instant happenedAt; // time client claims event happened
    private String type; // type of event

    /** Package-scoped constructor for JPA. */
    Event() { }

    /**
     * Constructor.
     */
    public Event(long accountId, Instant happenedAt, String type) {
        this.accountId = accountId;
        this.happenedAt = happenedAt;
        this.insertedAt = Instant.now();
        this.type = type;
    }

    public long getId() {
        return id;
    }
    public Instant getHappenedAt() {
        return happenedAt;
    }
    public String getType() {
        return type;
    }
}
