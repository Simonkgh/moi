/**
 * DTO classes used for persistence (whether to a database, message-broker, or other).
 * <p>
 * As these types may be instantiated by an ORM library, there are two options for a constructor:
 * (a) provide a default constructor, and mutable fields or (b) provide a suitably annotated constructor, in which
 * case the fields can be final. Having final fields is more elegant, but the constructor is often ugly - particularly
 * for types with many fields. Currently, option (a) has been taken for simplicity.
 * </p>
 * <p>
 * Ideally, rest-API-related code or concepts should be avoided in this package - including JSON annotations whose
 * purpose are to customise the representation of data returned to the client (breaks code layering). For this
 * demo, such details are being ignored..
 * </p>
 */
package com.example.demo.model;