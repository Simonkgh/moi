package com.example.demo.logic;

import com.example.demo.model.Account;
import com.example.demo.model.BasicPage;

/**
 * Functions related to manipulating instances of type Account.
 */
public interface AccountHandler {
    public static class AccountExists extends Exception {
    }

    public static class AccountNotFound extends Exception {
    }

    public static final int MAX_RESULTS = 10;

    long createAccount(String name) throws AccountExists, PersistenceException;

    BasicPage<Account> queryAccounts(String prefix, int page) throws PersistenceException;

    long idForName(String name) throws AccountNotFound, PersistenceException;

    Account forName(String name) throws AccountNotFound, PersistenceException;
}
