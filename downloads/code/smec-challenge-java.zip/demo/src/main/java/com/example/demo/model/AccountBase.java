package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.math.BigDecimal;

/**
 * Data model for business domain concept "AccountBase".
 * <p>
 * Event records do not reach back to the time at which the account was created; this record therefore records
 * the value of an account at the point in time that events begin for that account - ie represents the cumulative
 * state of all event records which have been discarded. Before old events for an account are discarded, the
 * corresponding AccountBase record is updated.
 * </p>
 */
@Entity
public class AccountBase {
    @Id
    private long id; // identical to account-id
    private BigDecimal balance;

    /** Package-scoped constructor for JPA. */
    AccountBase() { }
}
