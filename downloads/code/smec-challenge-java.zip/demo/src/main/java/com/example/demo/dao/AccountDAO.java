package com.example.demo.dao;

import java.util.List;

import com.example.demo.model.Account;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

/**
 * Interface defining which account-related database access methods Spring should auto-generate implementations for.
 */
public interface AccountDAO extends CrudRepository<Account, Long> {
    /** Return the single record with the specified key. */
    Account findById(long id);

    /** Return all records with the specified name (should be zero or one, as names are unique). */
    List<Account> findByName(String name);

    /**
     * Return all accounts whose name matches the specified prefix.
     *
     * @param namePattern is an SQL like-expression; "%" to return all accounts; "some%" to return all records with
     *                   name starting with "some", etc. Must not be null.
     */
    @Query(value = "select acc from Account acc where name like ?1")
    Page<Account> findByNamePattern(String namePattern, Pageable page);
}