/**
 * Package for spring/rest-specific code.
 * <p>
 * Code in this package acts as an adapter between spring/rest world and problem-domain types. Such code:
 * <ul>
 *     <li>should not implement any business logic</li>
 *     <li>should map incoming rest-related concepts to domain types</li>
 *     <li>convert results and exceptions into rest-appropriate types</li>
 * </ul>
 * </p>
 * <p>
 * Code in other packages of this application should not refer to rest types or concepts.
 * </p>
 */
package com.example.demo.rest;