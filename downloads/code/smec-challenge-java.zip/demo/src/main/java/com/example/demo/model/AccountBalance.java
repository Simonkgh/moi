package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.math.BigDecimal;

/**
 * Data model for business domain concept "AccountBalance".
 * <p>
 * The balance of an account is separate from an account because this application considers a balance to be
 * information derived from the list of events associated with an account (event sourcing).
 * </p>
 * <p>
 * In the current implementation, balance is updated synchronously with storage of an event but that may not
 * always be so.
 * </p>
 */
@Entity
public class AccountBalance {
    @Id
    private long id; // identical to account-id
    private BigDecimal balance;

    /** Package-scoped constructor for JPA. */
    AccountBalance() { }

    public long getId() { return id; }
    public BigDecimal getBalance() { return balance; }
}
