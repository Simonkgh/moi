package com.example.demo.rest.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Assert;
import org.junit.Test;

/**
 * Unit test for DTO class CreateAccountOut.
 * <p>
 * Yes, a unit-test for a DTO class is generally not very helpful. This class actually tests the way JSON serialization
 * acts with CreateAccountOut..
 * </p>
 */
public class CreateAccountOutTest {
    @Test
    public void testJsonSerializationForError() throws Exception {
        ObjectMapper om = new ObjectMapper();
        CreateAccountOut cao = new CreateAccountOut("some error");
        String s = om.writeValueAsString(cao);
        Assert.assertEquals("{\"error\":\"some error\"}", s);
    }

    @Test
    public void testJsonSerializationForAccount() throws Exception {
        ObjectMapper om = new ObjectMapper();
        CreateAccountOut cao = new CreateAccountOut(1L);
        String s = om.writeValueAsString(cao);
        Assert.assertEquals("{\"id\":1}", s);
    }
}
