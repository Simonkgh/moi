package com.example.demo.logic;

import com.example.demo.model.BasicPage;
import com.example.demo.model.Event;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.*;

/**
 * Implementation of EventHandler which just stores all events in memory - for test purposes only.
 * <p>
 * This behaviour could also be obtained for unit tests by using Mockito or similar, but a hand-written
 * class is sometimes just easier. This was also used initially for prototyping the REST apis...thus the
 * profile annotation :-)
 * </p>
 */
@Component
@Profile("mem")
public class EventHandlerMemImpl implements EventHandler {
    //mock
    private final Map<Long, List<Event>> eventsByAccount = new HashMap<>();

    public void publishEvent(long accountId, Instant happenedAt, String type) {
        Event e = new Event(accountId, happenedAt, type);
        if (!eventsByAccount.containsKey(accountId)) {
            eventsByAccount.put(accountId, new ArrayList<Event>());
        }
        eventsByAccount.get(accountId).add(e);
    }

    public BasicPage<Event> queryEvents(long accountId, Instant from, Instant to, int page) {
        // TODO: filter
        return new BasicPage(0, 1, eventsByAccount.get(accountId));
    }
}
