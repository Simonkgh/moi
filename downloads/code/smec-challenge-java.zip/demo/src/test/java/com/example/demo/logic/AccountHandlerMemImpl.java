package com.example.demo.logic;

import com.example.demo.model.Account;
import com.example.demo.model.BasicPage;
import org.springframework.context.annotation.Profile;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Implementation of AccountHandler which just stores all accounts in memory - for test purposes only.
 * <p>
 * This behaviour could also be obtained for unit tests by using Mockito or similar, but a hand-written
 * class is sometimes just easier. This was also used initially for prototyping the REST apis...thus the
 * profile annotation :-)
 * </p>
 */
@Component
@Profile("mem")
public class AccountHandlerMemImpl implements AccountHandler {
    private long nextId;
    private final Map<Long, Account> accountById = new HashMap<>();
    private final Map<String, Account> accountByName = new HashMap<>();

    /**
     * Inserts new account entity into the database and returns its auto-allocated key.
     */
    public long createAccount(String name) throws AccountExists {
        if (accountByName.containsKey(name)) {
            throw new AccountExists();
        }

        Account a = new Account(++nextId, name);

        accountById.put(a.getId(), a);
        accountByName.put(a.getName(), a);
        return a.getId();
    }

    private static boolean acceptAccount(Account a, String prefix, long from) {
        if (!a.getName().startsWith(prefix)) {
            return false;
        }

        if (a.getId() <= from) {
            return false;
        }

        return true;
    }

    public BasicPage<Account> queryAccounts(String prefix, int pageNum) {
        // mapping is simple as ids are always allocated in atomically increasing order and never deleted
        long from = pageNum * MAX_RESULTS;

        // select from Accounts where name like prefix% and id > from
        List<Account> results = accountById.values().stream()
                .filter(a -> acceptAccount(a, prefix, from))
                .collect(Collectors.toUnmodifiableList());

        // emulate too many results..
        if (results.size() < MAX_RESULTS) {
            return new BasicPage<>(0, 1, results);
        } else {
            return new BasicPage<>(0, 1, results.subList(0, MAX_RESULTS));
        }
    }

    public long idForName(String name) throws AccountNotFound {
        // Possibly could look up id in local cache here before querying DB..
        return forName(name).getId();
    }

    public Account forName(String name) throws AccountNotFound {
        // select from Accounts where name = name
        Account a = accountByName.get(name);
        if (a == null) {
            throw new AccountNotFound();
        }
        return a;
    }
}
