package com.example.demo.rest;

import com.example.demo.logic.AccountHandler;
import com.example.demo.logic.AccountHandlerMemImpl;
import com.example.demo.logic.EventHandler;
import com.example.demo.logic.EventHandlerMemImpl;
import com.example.demo.rest.api.CreateAccountOut;
import com.example.demo.rest.api.QueryAccountsOut;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

/**
 * Standard unit test for class AccountEndpoint.
 */
public class AccountEndpointTest {
    @Test
    public void testCreateSuccess() {
        // These handler objects could also be emulated using mock-objects, eg via the Mockito library.
        // But sometimes just using a hand-written "real" class is simpler..
        AccountHandler ah = new AccountHandlerMemImpl();
        EventHandler eh = new EventHandlerMemImpl();

        AccountEndpoint e = new AccountEndpoint(ah, eh);

        ResponseEntity<CreateAccountOut> rsp = e.createAccount("new1");
        Assert.assertEquals(HttpStatus.OK, rsp.getStatusCode());
        CreateAccountOut body = rsp.getBody();
        Assert.assertEquals(Long.valueOf(1), body.getId());
    }

    @Test
    public void testCreateDuplicate() {
        // These handler objects could also be emulated using mock-objects, eg via the Mockito library.
        // But sometimes just using a hand-written "real" class is simpler..
        AccountHandler ah = new AccountHandlerMemImpl();
        EventHandler eh = new EventHandlerMemImpl();

        AccountEndpoint e = new AccountEndpoint(ah, eh);

        ResponseEntity<CreateAccountOut> rsp = e.createAccount("new1");
        Assert.assertEquals(HttpStatus.OK, rsp.getStatusCode());

        rsp = e.createAccount("new1");
        Assert.assertEquals(HttpStatus.FORBIDDEN, rsp.getStatusCode());

        CreateAccountOut body = rsp.getBody();
        Assert.assertEquals("name exists", body.getError());
    }

    @Test
    public void testQueryAccounts() {
        AccountHandler ah = new AccountHandlerMemImpl();
        EventHandler eh = new EventHandlerMemImpl();
        AccountEndpoint e = new AccountEndpoint(ah, eh);

        ResponseEntity<CreateAccountOut> rsp1 = e.createAccount("new1");
        Assert.assertEquals(HttpStatus.OK, rsp1.getStatusCode());

        ResponseEntity<QueryAccountsOut> rsp2 = e.queryAccounts(null, null);
        Assert.assertEquals(HttpStatus.OK, rsp2.getStatusCode());

        QueryAccountsOut qo = rsp2.getBody();
        Assert.assertEquals(0, qo.getPageNum());
        Assert.assertEquals(1, qo.getPageMax());
        Assert.assertEquals(1, qo.getAccounts().size());
        Assert.assertEquals("new1", qo.getAccounts().get(0).getName());
    }
}
